package com.example.userapi.service;

import com.example.userapi.exception.DuplicateResourceException;
import com.example.userapi.exception.ResourceNotFoundException;
import com.example.userapi.model.User;
import com.example.userapi.repository.UserRepository;
import java.util.List;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/** Business logic layer: sits between the controller and the repository. */
@Service
public class UserService {

    private final UserRepository userRepository;

    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Transactional(readOnly = true)
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    @Transactional(readOnly = true)
    public User getUserById(Long id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id " + id));
    }

    @Transactional
    public User createUser(User user) {
        if (userRepository.existsByEmail(user.getEmail())) {
            throw new DuplicateResourceException("Email already in use: " + user.getEmail());
        }
        user.setId(null); // ignore any id sent by the client
        return userRepository.save(user);
    }

    @Transactional
    public User updateUser(Long id, User details) {
        User existing = getUserById(id);
        if (userRepository.existsByEmailAndIdNot(details.getEmail(), id)) {
            throw new DuplicateResourceException("Email already in use: " + details.getEmail());
        }
        existing.setName(details.getName());
        existing.setEmail(details.getEmail());
        existing.setAge(details.getAge());
        return userRepository.save(existing);
    }

    @Transactional
    public void deleteUser(Long id) {
        User existing = getUserById(id);
        userRepository.delete(existing);
    }
}
